Texas Instruments, Inc.

Bluetooth Developer Studio Plugin
Readme

TI-BDS-PLUGIN Version 1.0.8
January 25th, 2017



Getting Started
================

See [CHANGELOG.txt](CHANGELOG.txt) for information about implemented features, known issues, etc.

You will need [Bluetooth Developer Studio](https://www.bluetooth.com/~/media/developer-studio/index) in order to use this plugin.

The files in the same folder as this text file should be copied into:
`C:\Program Files (x86)\Bluetooth SIG\Bluetooth Developer Studio\Plugins\Texas Instruments -- Embedded Profiles\*.*`

Open Bluetooth Developer Studio and create your profile. When you want to generate the code, click on TOOLS->GENERATE CODE.

Note: For best variable name generation, use spaces in your service and characteristic names, for examle "my cool service", as the generated names will split on spaces.


The files that are created in the output folder selected in BDS are:
**Profile_Name_TI(_SDK30|_SDK22)/**
--- `service_name.c` per service
--- `service_name.h` per service
--- `app_snippets.c`
--- `simple_peripheral_bds.c`, using the generated services.
--- `project_zero_bds.c`, using the generated services
--- `log.txt`, replica of the BDS plugin log

For support and feedback, please visit www.ti.com/ble-forum.

Test output using TI SimpleLink CC2640R2 SDK 1.00.00.22
=======================================================

Required software:

* SimpleLink CC2640R2 SDK 1.00.00.22 from www.ti.com/ble-stack.
* IAR Embedded Workbench for ARM, or Code Composer Studio v7.0

Required extras for Project Zero:

* Download from the `ble_examples` repository on GitHub
  * Repository: https://github.com/ti-simplelink/ble_examples/tree/ble_examples-3.0
  * ZIP file: https://github.com/ti-simplelink/ble_examples/archive/ble_examples-3.0.zip

### Using IAR

#### Simple Peripheral

* Open the example project workspace, found at: `simplelink_cc2640r2_sdk_1_00_00_22\examples\rtos\CC2640R2_LAUNCHXL\blestack\simple_peripheral\tirtos\iar`

  * See the BLE SDK's included Software Developers Guide for more information on the software development kit in general.

* Copy the generated files to the same folder as the user application task to avoid dealing with include paths. In this example:
   - `simplelink_cc2640r2_sdk_1_00_00_22\examples\rtos\CC2640R2_LAUNCHXL\blestack\simple_peripheral\src\app`

* Drag+drop the files copied to the app folder into the GUI, except `app_snippets.c`.

* Right click on `simple_peripheral.c`, select `Options..` and check `Exclude from build`.

* Build and program

* **NOTE**: You can also link directly from the BDS output directory by dragging the files from there into the GUI, but these files will then be overwritten the next time BDS generates code.


### Using CCS

#### Simple Peripheral
* For simple_peripheral, copy `simple_peripheral_bds.c` and the generated service source files to the same folder as the user application task. In this example:
   - `simplelink_cc2640r2_sdk_1_00_00_22\examples\rtos\CC2640R2_LAUNCHXL\blestack\simple_peripheral\src\app`

* Drag+drop the files copied to the app folder into the GUIs `Application` folder, except `app_snippets.c` and select 'Link to' in the dialog box that pops up.

* Right click on the original `simple_peripheral.c` file in Project Explorer and click `Exclude from build`.

* Build and program


#### Project Zero

* Import the project files from where you downloaded the content from the repository
  * File --> Import --> Code Composer Studio --> CCS Projects, and select the folder
  * `ble_examples\examples\rtos\CC2640R2_LAUNCHXL\blestack\cc2640r2_project_zero\tirtos\ccs`

* For Project Zero, drag+drop `project_zero_bds.c` and the generated service source files directly from the output directory into the `Application` folder and select 'Copy files'.

* Right click on the original `project_zero.c` file in Project Explorer and click `Exclude from build`.

* Build and program


Test output using TI BLE SDK 2.2.x
===========================

Required software:

* BLE SDK v2.2 from www.ti.com/ble-stack.
* IAR Embedded Workbench for ARM, or Code Composer Studio v6.2+

Required extras for Project Zero:

* SimpleLink Academy 1.10+ installed on your computer along with CCS 6.2+
  * http://software-dl.ti.com/lprf/simplelink_academy/overview.html
  * Contains the Project Zero project, which is not included in the SDK

### Using IAR

Only Simple BLE Peripheral is supported with IAR.

* Open the example project workspace, found at: `C:\ti\simplelink\ble_sdk_2_02_00_31\examples\<board>\simple_peripheral\iar`

  * See the BLE SDK's included Software Developers Guide for more information on the software development kit in general.

* Copy the generated files to the same folder as the user application task to avoid dealing with include paths. In this example:
   - `C:\ti\simplelink\ble_sdk_2_02_00_31\src\examples\simple_peripheral\cc26xx\app`

* Drag+drop the files copied to the app folder into the GUI, except `app_snippets.c`.

* Right click on `simple_peripheral.c`, select `Options..` and check `Exclude from build`.

* Build and program

* **NOTE**: You can also link directly from the BDS output directory by dragging the files from there into the GUI, but these files will then be overwritten the next time BDS generates code.


### Using CCS

#### Simple Peripheral
* For simple_peripheral, copy `simple_peripheral_bds.c` and the generated service source files to the same folder as the user application task. In this example:
   - `C:\ti\simplelink\ble_sdk_2_02_00_31\src\examples\simple_peripheral\cc26xx\app`

* Drag+drop the files copied to the app folder into the GUIs `Application` folder, except `app_snippets.c` and select 'Link to' in the dialog box that pops up.

* Right click on the original `simple_peripheral.c` file in Project Explorer and click `Exclude from build`.

#### Project Zero
* For Project Zero, drag+drop `project_zero_bds.c` and the generated service source files directly from the output directory into the `Application` folder and select 'Copy files'.

* Right click on the original `project_zero.c` file in Project Explorer and click `Exclude from build`.

Custom parameters for TI plugin
=================================

Some functionality is added to the plugin on top of what's available in the Bluetooth Developer Studio GUI.  This is currently only utilized by the generated ProjectZero application file.

The purpose of these custom properties is to generate application code that utilize a characteristic in a specific way.

To use these, expand the properties of a `Characteristic` in the BDS GUI and click on `CUSTOM PROPERTIES` at the bottom of this view.

Property `INBUTTON`
--------------------------------

This property can be used to generate debounce logic for a pin, and after debounce set the first byte of the characteristic value to the state of the pin.

Property `INPIN`
--------------------------

This property can be used to generate code that directly connects a pin interrupt to the `SetParameter` API of the service, setting the first byte of the value to the state of the pin.

Property `OUTPIN`
---------------------------

This property can be used to generate code that will set the pin state when an over the air write is received for the selected characteristic. The first byte of the received data will be used to set the pin state.

Examples
--------------
Note that the value must correspond to a `#define` which exists globally. This can be either from the board file like `Board_LED0` or a generic IO reference like `IOID_21`.


Property | Value
-------- | -------
OUTPIN   | Board_LED0
INBUTTON | Board_BUTTON0
INPIN    | IOID_02

See also the BDS example project for Project Zero that is bundled with this plugin.
