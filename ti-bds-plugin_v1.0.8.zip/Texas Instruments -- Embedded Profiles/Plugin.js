/*
Filename:       Plugin.js

Description:    Service generator for Bluetooth Developer Studio

Copyright (c) 2015-2017, Texas Instruments Incorporated
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

*  Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

*  Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

*  Neither the name of Texas Instruments Incorporated nor the names of
   its contributors may be used to endorse or promote products derived
   from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

function GetInfo(infoObject)
{
    infoObject.Name = "Texas Instruments BLE SDK GATT Server plugin";
    infoObject.Description = "This plugin generates code compatible with the on-chip GATT Server for BLESTACK 2.2 and 3.0";
    infoObject.Author = "Texas Instruments, Inc.";
    infoObject.Version = "1.0.8";
    infoObject.IsClient = false;
    infoObject.IncludeDefaultServices = false;
    return infoObject;
}

function OmitNull(value)
{

    if( value == null )
    {
        return "";
    }
    else
    {
        return value;
    }

}



function nameUnspecialize(n, extraFilter)
{
  if (n)
  {
    n = n.replace(/[\.,;:]/g, ''); // Completely ignore punctuation
    if (extraFilter)
      n = n.replace(extraFilter, ''); // Completely ignore punctuation
    if (n.match(/(^[0-9])/)) // Identifiers cannot start with number
      n = '_' + n;
    return n.replace(/[^A-Za-z0-9]/g, ' '); // Replace the rest with spaces
  }
}

// Eg: The game is up --> The_game_is_up
function nameUnderscored(n)
{
  if (n)
  {
    return nameUnspecialize(n).replace(/\s/g,'_');
  }
}

// Eg: Santa Claus is coming to town --> scictt
function nameAbbreviated(n)
{
  if (n)
  {
    return nameUnspecialize(n).split(' ').reduce(function(prev, cur) { return prev + cur.charAt(0).toLowerCase() }, '');
  }
}

// Eg: Sauce tastes pretty well --> sauceTastesPrettyWell
function nameCamelized(n)
{
  if (n)
  {
    return nameUnspecialize(n).split(' ')
      .map(
        function(d, i) {
          return (i?d.charAt(0).toUpperCase():d.charAt(0).toLowerCase()) + d.slice(1).toLowerCase();
        })
      .reduce(
        function(prev, cur){
          return prev + cur;
        }, '');
  }
}

// Eg: winter is coming --> WinterIsComing
function nameCapitalized(n)
{
  if (n)
  {
    camel = nameCamelized(n)
    return camel.charAt(0).toUpperCase() + camel.slice(1);
  }
}

function makeBaseUuidMacro(uuid)
{
  // Assume baseUuid is on the form fbc6b322-6b93-43a4-9fcd-a9c830b00c19 and make an c-array string
  var baseUuidBare = uuid.replace(/-/g,''); // As of version FC-1, the '-' are not there anyway
  var baseUuidArray = ''; // = '{';
  for (var x = baseUuidBare.length - 2; x >= 0; x -= 2)
  {
    if (x == 4)
      baseUuidArray += 'HI_UINT16(uuid)'
    else if (x == 6)
      baseUuidArray += 'LO_UINT16(uuid)'
    else
      baseUuidArray += '0x' + baseUuidBare.slice(x, x+2)
    if (x > 0)
      baseUuidArray += ', ';
  }
//  baseUuidArray += '}'
  // Now on the form {0x19, 0x0c, 0xb0, 0x30, 0xc8, 0xa9, 0xcd, 0x9f, 0xa4, 0x43, 0x93, 0x6b, LO_UINT16(uuid), HI_UINT16(uuid), 0xc6, 0xfb}
  return baseUuidArray;
}


function extract16bitUuid(uuid)
{
  if (uuid.length == 36) // On the form fbc6b322-6b93-43a4-9fcd-a9c830b00c19
  {
    return uuid.slice(4,8);
  }
  else if (uuid.length == 32) // On the form 642C8A2838C9405DADA4002F00B69A80
  {
    return uuid.slice(4,8);
  }
}


// Intercept and save the log output to file.
var logHolder = '';
function getLog() { return logHolder; }
function replaceLog() {
  var realLog = log;
  return function(l) { logHolder += l + '\r\n'; realLog(l); };
}

function RunPlugin(profiledata)
{
  log = replaceLog();

  // Include liquid.js
  var liqFile = FileManager.ReadFile('liquid.js');
  eval(liqFile); // Eval?

  // Add the 'slice' filter. {{ "Thing" | slice: 1, 3 }} -> "hin".
  Liquid.Template.registerFilter({
    slice: function(input, offset, length)
    {
      offset = offset || 0;
      length = length || 50;
      return (input.length > length+offset)?input.slice(offset,length):input;
    },
    split: function(input, separator) {
      separator = separator ||  '';
      return input.split(separator);
    },
    json: function(input) {
      return JSON.stringify(input);
    },
    truncate: function(input, length, string) { /*better truncate*/
      if(!input || input == ''){ return ''; }
      length = length || 50;
      string = string || "...";

      var seg = input.slice(0, length);
      return (input.length > length ?
              input.slice(0, length-string.length) + string :
              input);
    },
  });

  // Initialize
  var output = "";
  var formJson = {'services': []};

  // Add version and date information.
  var pluginInfo = {};
  pluginInfo.AppVersion = profiledata.AppVersion;
  pluginInfo = GetInfo(pluginInfo);
  pluginInfo.timestamp = Date().toString();
  formJson.pluginInfo = pluginInfo;
  formJson.fluff = true;
  formJson.profileName = nameCapitalized(profiledata.ProfileName);
  formJson.pins = {'list': [], 'numPins': 0, 'numButtons': 0, 'numOutput': 0, 'numInput': 0};


  var renderOutPath = formJson.profileName + '_TI';
  FileManager.CreateFolder(renderOutPath + '_SDK22');
  FileManager.CreateFolder(renderOutPath + '_SDK30');


  var serviceHeaderTemplateParsed = Liquid.parse(FileManager.ReadFile("service.h"));
  var serviceCodeTemplateParsed = Liquid.parse(FileManager.ReadFile("service.c"));
  var appSnippetsTemplate = Liquid.parse(FileManager.ReadFile("appsnippets.c"));
  var SBPTemplate = Liquid.parse(FileManager.ReadFile("simple_peripheral_bds.c"));
  var SBPTemplate30 = Liquid.parse(FileManager.ReadFile("simple_peripheral_3_0_0_bds.c"));
  var PRZTemplate = Liquid.parse(FileManager.ReadFile("project_zero_bds.c"));
  var PRZTemplate30 = Liquid.parse(FileManager.ReadFile("project_zero_3_x_bds.c"));

  var baseUuid = profiledata.BaseUUID;
  var baseUuidMacro = makeBaseUuidMacro(baseUuid);




  for (var x = 0; x < profiledata.Services.length; x++)
  {
    var service = profiledata.Services[x];
    var Svc = {};
    var CustomProps = {};


    log("Service name: " + service.Name);
    Svc.nameNice = service.Name;
    Svc.nameAbbr = nameAbbreviated(Svc.nameNice);
    Svc.nameCamel = nameCamelized(Svc.nameNice);
    Svc.nameCap = nameCapitalized(Svc.nameNice);
    Svc.name = nameUnderscored(Svc.nameNice);
    Svc.filename = nameUnderscored(Svc.nameNice).toLowerCase();

    // Massage the UUID
    if (service.UUID.length > 4)
    {
      Svc.uuidRaw = service.UUID;
      Svc.uuid = extract16bitUuid(service.UUID);
      Svc.baseUuidMacro = makeBaseUuidMacro(service.UUID);
    }
    else
    {
      Svc.uuidRaw = service.UUID;
      Svc.uuid = service.UUID;
      Svc.baseUuidMacro = makeBaseUuidMacro(baseUuid); // Won't be used if adopted anyway.
    }

    // Add 0x so it becomes a bona fide 16-bit integer
    Svc.uuid = '0x' + Svc.uuid;

    // Determine that it should use 16-bit UUID if it's an adopted profile, otherwise some other base UUID.
    Svc.type = '' + service.Type;
    //if (service.Type.indexOf('org.bluetooth') > -1)
    if (service.UUID.length == 4) // Use UUID length since profileData makes sense now.
      Svc.uuid_size = 'ATT_BT_UUID_SIZE';
    else
      Svc.uuid_size = 'ATT_UUID_SIZE';

    Svc.chars = []
    Svc.pins = {'list': [], 'numPins': 0, 'numButtons': 0, 'numOutput': 0, 'numInput': 0};
    for( var y = 0; y < service.Characteristics.length; y++)
    {
      var c = service.Characteristics[y];

      // Skip excluded ones alltogether.
      if (c.Requirement == 'Excluded')
        continue;

      var Char = {};

      Char.idx = y;
      Char.nameNice = c.Name;
      Char.nameAbbr = nameAbbreviated(Char.nameNice);
      Char.nameCamel = nameCamelized(Char.nameNice);
      Char.nameCap = nameCapitalized(Char.nameNice);
      Char.name = nameUnderscored(Char.nameNice);
      log("Processing char: " + Char.nameNice);

      Char.req = c.Requirement;
      Char.type  = c.Type;

      // Massage the UUID
      if (c.UUID.length > 4)
      {
        Char.uuid = extract16bitUuid(c.UUID);
        Char.baseUuidMacro = makeBaseUuidMacro(c.UUID);
      }
      else
      {
        Char.uuid = c.UUID;
        Char.baseUuidMacro = makeBaseUuidMacro(baseUuid); // Won't be used if adopted anyway.
      }
      Char.uuid = '0x' + Char.uuid;
      //if (Char.type.indexOf('org.bluetooth') > -1)
      if (c.UUID.length == 4) // Use UUID length since profileData makes sense now.
        Char.uuid_size = 'ATT_BT_UUID_SIZE';
      else
        Char.uuid_size = 'ATT_UUID_SIZE';

      Char.len = 1; // Don't know where to get this information.

      Char.properties = [];
      Char.permissions = [];


      // TODO: Properties is now a list per characteristic. Find out why this makes sense.
      for (var pr = 0; pr < c.Properties.length; pr++)
      {
        var charProps = c.Properties[pr];

        if (charProps.Notify != 'Excluded')
        {
          Char.properties.push('GATT_PROP_NOTIFY')
          // if (!('GATT_PERMIT_READ' in Char.permissions))
          // {
          //   Char.permissions.push('GATT_PERMIT_READ')
          // }
          Char.isNotify = true;
        }

        if (charProps.Indicate != 'Excluded')
        {
          Char.properties.push('GATT_PROP_INDICATE')
          // if (!('GATT_PERMIT_READ' in Char.permissions))
          // {
          //   Char.permissions.push('GATT_PERMIT_READ')
          // }
          Char.isIndicate = true;
        }


        if (charProps.Read != 'Excluded')
        {
          Char.properties.push('GATT_PROP_READ')
          if (!('GATT_PERMIT_READ' in Char.permissions))
            Char.permissions.push('GATT_PERMIT_READ')
          Char.isReadable = true;
        }

        if (charProps.Write != 'Excluded')
        {
          if (!('GATT_PROP_WRITE' in Char.properties))
            Char.properties.push('GATT_PROP_WRITE')
          if (!('GATT_PERMIT_WRITE' in Char.permissions))
            Char.permissions.push('GATT_PERMIT_WRITE')
          Char.isWritable = true;
        }

        if (charProps.WriteWithoutResponse != 'Excluded')
        {
          if (!('GATT_PROP_WRITE_NO_RSP' in Char.properties))
            Char.properties.push('GATT_PROP_WRITE_NO_RSP')
          if (!('GATT_PERMIT_WRITE' in Char.permissions))
            Char.permissions.push('GATT_PERMIT_WRITE')
          Char.isWritable = true;
        }
      }

      // Sum up the fields
      Char.fields = [];

      // Fields
      for( var z = 0; z < c.Fields.length; z++ )
      {
        var field = c.Fields[z];
        var jf = {};

        jf.id = z;
        jf.nameNice = field.Name;
        jf.nameAbbr = nameAbbreviated(jf.nameNice);
        jf.nameCamel = nameCamelized(jf.nameNice);
        jf.nameCap = nameCapitalized(jf.nameNice);
        jf.name = nameUnderscored(jf.nameNice)
        jf.format = OmitNull(field.Format);
        jf.requirements = []; // Ignore for now
        jf.min = OmitNull(field.Minimum);
        jf.max = OmitNull(field.Maximum);
        jf.repeated = OmitNull(field.Repeated);

        //log("Found field: " + jf.nameNice);

        jf.enumerations = [];

        // Enumerations
        if (field.Enumerations && field.Enumerations.Enumeration)
        {
          for (var enumId = 0; enumId < field.Enumerations.Enumeration.length; enumId++) {
            var enumeration = field.Enumerations.Enumeration[enumId];
            var jenum = {};
            jenum.id = enumId;
            jenum.key = enumeration.Key;
            jenum.value = enumeration.Value;
            jenum.requires = OmitNull(enumeration.Requires);
            jenum.desc = OmitNull(enumeration.Description);
            jf.enumerations.push(jenum);
          }
        }

        jf.bits = [];

        if (field.BitField && field.BitField.Bits)
        {
          for (var bitId = 0; bitId < field.BitField.Bits.length; bitId++)
          {
            var bit = field.BitField.Bits[bitId];
            var jbit = {};
            jbit.id = bitId;
            jbit.nameNice = OmitNull(bit.Name);
            jbit.nameAbbr = nameAbbreviated(jbit.nameNice);
            jbit.nameCamel = nameCamelized(jbit.nameNice);
            jbit.nameCap = nameCamelized(jbit.nameNice);
            jbit.name = nameUnderscored(jbit.nameNice);
            jbit.index = bit.Index;
            jbit.size = bit.Size;
            jbit.enumerations = [];

            if (bit.Enumerations && bit.Enumerations.Enumeration)
            {
              for (var enumId = 0; enumId < bit.Enumerations.Enumeration.length; enumId++) {
                var enumeration = bit.Enumerations.Enumeration[enumId];
                var jenum = {};
                jenum.id = enumId;
                jenum.key = enumeration.Key;
                jenum.value = enumeration.Value;
                jenum.requires = OmitNull(enumeration.Requires);
                jenum.desc = OmitNull(enumeration.Description);
                jbit.enumerations.push(jenum);
              }
            }
            jf.bits.push(jbit);
          }
        }

        var numBits = 0; // Start off with 0 and add iteratively.
        //log("Calculating char length");
        if (jf.format.indexOf('8s') > -1)
          numBits = -1;
        else if (jf.format.indexOf('16s') > -1)
          numBits = -1;
        else if (jf.format.indexOf('variable') > -1)
          numBits = -1;
        else if (jf.format.indexOf('uint8[]') > -1)
          numBits = -1;
        else if (jf.format.indexOf('boolean') > -1)
          numBits = 8;
        else if (jf.format.indexOf('16') > -1)
          numBits += 16;
        else if (jf.format.indexOf('24') > -1)
          numBits += 24;
        else if (jf.format.indexOf('32') > -1)
          numBits += 32;
        else if (jf.format.indexOf('40') > -1)
          numBits += 40;
        else if (jf.format.indexOf('48') > -1)
          numBits += 48;
        else if (jf.format.indexOf('64') > -1)
          numBits += 64;
        else if (jf.format.indexOf('128') > -1)
          numBits += 128;
        else if (jf.format.indexOf('2') > -1)
          numBits += 2;
        else if (jf.format.indexOf('4') > -1)
          numBits += 4;
        else if (jf.format.indexOf('nibble') > -1)
          numBits += 4;
        else if (jf.format.indexOf('8') > -1)
          numBits += 8;
        else if (jf.format.indexOf('12') > -1)
          numBits += 12;
        else
          numBits = -1;

        jf.numBits = numBits;
        //log('NumBits: ' + numBits);
        Char.fields.push(jf);
      }

      // Determine length of characteristic
      var varLength = false;
      var charNumBitsMin = 0;
      for (var i = 0; i < Char.fields.length; i++)
      {
        var f = Char.fields[i];

        if (varLength && f.numBits == -1)
          log("  Warning: Variable field '"+f.nameNice+"' found after a variable length field. Implicit length calculation will not be possible.");

        if (f.numBits == -1)
          varLength = true;
        else
          charNumBitsMin += f.numBits;
      }

      if (charNumBitsMin == 0 && !varLength)
      {
        log("  No field length information available. Using length = 1.")
        charNumBitsMin = 8;
        charNumBitsMax = 8;
      }
      else
      {
        // charNumBitsMin already calculated.
        if (varLength)
        {
          charNumBitsMax = 20 * 8; // Use 20 bytes default max length if variable.
          log("  Variable length fields in char, setting max length to 20 bytes");
        }
        else
        {
          charNumBitsMax = charNumBitsMin;
          log("  No variable length fields, setting max length equal to min length.");
        }
      }

      Char.len = Math.ceil(charNumBitsMax/8);
      Char.lenMin = Math.ceil(charNumBitsMin/8);
      if (Char.lenMin == 0) Char.lenMin = 1; // Minimum 0 doesn't make sense and causes warnings.
      log('  ' + Char.fields.length + ' fields in char.');
      log('  Allocated (max) length calculated to: ' + Char.len + ' bytes');
      log('  Minimum length calculated to: ' + Char.lenMin + ' bytes.')

      // Custom properties
      for (var i = 0; i < c.CustomProperties.length; i++)
      {
        log("      (Custom Property #" + (i) + ")");
        var proKey = c.CustomProperties.GetKey(i);
        log("      Custom Property #" + (i) + " Key: " + proKey);
        var proValueByKey = c.CustomProperties.GetValue(i);
        var proValueByIndex = c.CustomProperties.GetValue(proKey);

        if (proValueByKey == proValueByIndex)
        {
          log("      Custom Property #" + (i) + " Value: " + proValueByKey);
        }
        else
        {
            log("      (Value returned inconsistently by different access methods)");
            log("      Custom Property #" + (i) + " Value (by Key): " + proValueByKey);
            log("      Custom Property #" + (i) + " Value (by Index): " + proValueByIndex);
        }

        // Add to pin list if applicable
        if (proKey == 'INBUTTON')
        {
          var pin = {};
          pin.define = proValueByKey;
          pin.nameCap = nameCamelized(nameUnspecialize(proValueByKey, /Board_/));
          pin.input = false;
          pin.output = false;
          pin.button = true;
          pin.irq = (Char.isIndicate || Char.isNotify)?true:false;
          pin.service = Svc;
          pin.char = Char;

          formJson.pins.numPins += 1;
          formJson.pins.numButtons += 1;
          formJson.pins.numInput += 1;
          formJson.pins.list.push(pin);

          Svc.pins.numPins += 1;
          Svc.pins.numButtons += 1;
          Svc.pins.numInput += 1;
          Svc.pins.list.push(pin);

          Char.pin = pin;
        }
        if (proKey == 'INPIN')
        {
          var pin = {};
          pin.define = proValueByKey;
          pin.nameCap = nameCamelized(nameUnspecialize(proValueByKey, /Board_/));
          pin.input = true;
          pin.output = false;
          pin.button = false;
          pin.irq = (Char.isIndicate || Char.isNotify)?true:false;
          pin.service = Svc;
          pin.char = Char;

          formJson.pins.numPins += 1;
          formJson.pins.numInput += 1;
          formJson.pins.list.push(pin);

          Svc.pins.numPins += 1;
          Svc.pins.numInput += 1;
          Svc.pins.list.push(pin);

          Char.pin = pin;
        }
        if (proKey == 'OUTPIN')
        {
          var pin = {};
          pin.define = proValueByKey;
          pin.nameCap = nameCamelized(nameUnspecialize(proValueByKey, /Board_/));
          pin.input = false;
          pin.output = true;
          pin.button = false;
          pin.irq = false;
          pin.service = Svc;
          pin.char = Char;

          formJson.pins.numPins += 1;
          formJson.pins.numOutput += 1;
          formJson.pins.list.push(pin);

          Svc.pins.numPins += 1;
          Svc.pins.numOutput += 1;
          Svc.pins.list.push(pin);

          Char.pin = pin;
        }

      }

      // Push into the service
      Svc.chars.push(Char);

    }



    // Massage characteristic objects.
    if (Svc.chars)
    {
      // Remove empty characteristics - in case they've been removed.
      Svc.chars = Svc.chars.filter(function(d){if (d) return true;});

      // Capitalized name
      Svc.chars.forEach(function(d){d.nameCap = d.name.charAt(0).toUpperCase() + d.name.slice(1);})

      // Generate nice lists of properties and permissions.
      Svc.chars.forEach(function(d){
        d.orProps = d.properties?(d.properties.join(' | ')):0;
      })

      Svc.chars.forEach(function(d){
        d.orPerms = d.permissions?(d.permissions.join(' | ')):0;
      })

      // Make list of characteristics that need a readcallback and SetParam.
      Svc.charsNeedRead = Svc.chars.filter(
        function(d){
          return ( (d.properties && d.properties.indexOf('GATT_PROP_NOTIFY') >= 0) ||
          (d.properties && d.properties.indexOf('GATT_PROP_INDICATE') >= 0) ||
          (d.permissions && d.permissions.indexOf('GATT_PERMIT_READ') >= 0 ) );
        })
      Svc.numNeedRead = (Svc.charsNeedRead)?Svc.charsNeedRead.length:0;
      //log("NeedRead -- " + Svc.charsNeedRead.toString());
      // Make list of characteristics that are ATT readable.
      Svc.charsReadable = Svc.chars.filter(
        function(d){
          return ( (d.properties && d.properties.indexOf('GATT_PROP_READ') >= 0) );
        })

      Svc.numReadable = (Svc.charsReadable)?Svc.charsReadable.length:0;

      // Make list of characteristics that can be written.
      Svc.charsNeedWrite = Svc.chars.filter(
        function(d){
          return ( d.permissions && d.permissions.indexOf('GATT_PERMIT_WRITE') >= 0 );
        })

      Svc.writeable = Svc.charsNeedWrite.length; /* legacy */
      Svc.numWriteable = (Svc.charsNeedWrite)?Svc.charsNeedWrite.length:0;

      // Make list of characteristics with CCCDs
      Svc.charsHaveCCCDs = Svc.chars.filter(
        function(d){
          return (d.properties && d.properties.indexOf('GATT_PROP_NOTIFY') >= 0) ||
                 (d.properties && d.properties.indexOf('GATT_PROP_INDICATE') >= 0) ;
        })

      Svc.numCCCDs = (Svc.charsHaveCCCDs)?Svc.charsHaveCCCDs.length:0;

      // Whether the chars have CCCDs
      if (Svc.chars)
        Svc.chars.forEach(function(d){
          d.hasCCCD = (d.properties && d.properties.indexOf('GATT_PROP_NOTIFY') >= 0) ||
                      (d.properties && d.properties.indexOf('GATT_PROP_INDICATE') >= 0) ;
        })

    }



    var s = {'service': Svc, 'fluff': 'true', 'pluginInfo': pluginInfo};

    log('---------------');

    var rendered = serviceHeaderTemplateParsed.render(s);
    FileManager.CreateFile(renderOutPath + '_SDK22/' + Svc.filename + ".h", rendered);
    log("Generated header file: " + renderOutPath + '_SDK22/' + Svc.filename + ".h");

    var rendered = serviceCodeTemplateParsed.render(s);
    FileManager.CreateFile(renderOutPath + '_SDK22/' + Svc.filename + ".c", rendered);
    log("Generated code file: " + renderOutPath + '_SDK22/' + Svc.filename + ".c");

    var rendered = serviceHeaderTemplateParsed.render(s);
    FileManager.CreateFile(renderOutPath + '_SDK30/' + Svc.filename + ".h", rendered);
    log("Generated header file: " + renderOutPath + '_SDK30/' + Svc.filename + ".h");

    var rendered = serviceCodeTemplateParsed.render(s);
    FileManager.CreateFile(renderOutPath + '_SDK30/' + Svc.filename + ".c", rendered);
    log("Generated code file: " + renderOutPath + '_SDK30/' + Svc.filename + ".c");

    formJson.services.push(Svc);
  }


  function parseGapSettings(profiledata, formJson)
  {
    if (profiledata.GAPProperties == null)
      return undefined;

    function findService(formJson, uuid, name)
    {
      for (var i = 0; i < formJson.services.length; i++)
        if (formJson.services[i].uuidRaw.toLowerCase().indexOf(uuid.toLowerCase()) >= 0)
          return formJson.services[i];

      // There seems to be some sort of bug in BDS, where the adv list doesn't get the 16-bit
      // version of the UUID if it's 16bit. Compare names as a last resort.
      for (var i = 0; i < formJson.services.length; i++)
        if (formJson.services[i].nameNice.indexOf(name) >= 0)
          return formJson.services[i];
    }

    // Handle GAP settings
    gap = {};
    gap.deviceName = profiledata.GAPProperties.DeviceName;
    gap.useShortName = '' + profiledata.GAPProperties.UseShortName;
    gap.useShortName = (gap.useShortName.indexOf('true')>=0);
    gap.useLen = (gap.useShortName)?profiledata.GAPProperties.ShortNameBytes:gap.deviceName.length;
    gap.discMode = profiledata.GAPProperties.DiscoveryMode;

    gap.servicesAdv = profiledata.GAPProperties.ServicesAdvertise;
    gap.servicesRsp = profiledata.GAPProperties.ServicesResponse;
    gap.deviceNameAdv = profiledata.GAPProperties.DeviceNameAdvertise;
    gap.deviceNameRsp = profiledata.GAPProperties.DeviceNameResponse;

    gap.txPowerAdv = profiledata.GAPProperties.TXPowerAdvertise;
    gap.txPowerRsp = profiledata.GAPProperties.TXPowerResponse;
    gap.txPower = profiledata.GAPProperties.TXPower;

    gap.serviceAdv16b = [];
    gap.serviceAdv128b = [];
    for (var a = 0; a < profiledata.GAPProperties.ServicesAdvertisement.length; a++)
    {
      var serviceAdvertisement = profiledata.GAPProperties.ServicesAdvertisement[a];
      isSelected = ''+serviceAdvertisement.Selected;
      isSelected = (isSelected.indexOf('true')>=0);
      if (!isSelected)
        continue;

      var svc = {};
      svc.name = serviceAdvertisement.Name;
      svc.uuid = ''+serviceAdvertisement.UUID;
      svc.selected = serviceAdvertisement.Selected;
      svc.lookup = findService(formJson, svc.uuid, svc.name);

      if (svc.lookup.uuidRaw.length > 4)
        gap.serviceAdv128b.push(svc);
      else
        gap.serviceAdv16b.push(svc);
    }

    // Figure out length of adv data for warnings.

    return gap;
  }

  // Figure out if any services can be written to
  formJson.anyWriteable = formJson.services.reduce(function(prev,cur){return prev + cur.writeable}, 0);

  // Figure out if any services have CCCDs
  formJson.anyCCCDs = formJson.services.reduce(function(prev,cur){return prev + cur.numCCCDs}, 0);
  formJson.numCCCDs = formJson.anyCCCDs;

  // Figure out if any services are readable
  formJson.anyReadable = formJson.services.reduce(function(prev,cur){return prev + cur.numReadable}, 0);
  formJson.numReadable = formJson.anyReadable;

  // Parse GAP things
  formJson.gap = parseGapSettings(profiledata, formJson)

  var rendered = appSnippetsTemplate.render(formJson);
  FileManager.CreateFile(renderOutPath + "_SDK22/app_snippets.c", rendered);
  FileManager.CreateFile(renderOutPath + "_SDK30/app_snippets.c", rendered);
  log("Generated code file: "+renderOutPath+"/app_snippets.c");
  log("Contains example usage of generated services.")


  var rendered = SBPTemplate.render(formJson);
  FileManager.CreateFile(renderOutPath + "_SDK22/simple_peripheral_bds.c", rendered);
  log("Generated code file: "+renderOutPath+"_SDK22/simple_peripheral_bds.c");
  var rendered = SBPTemplate30.render(formJson);
  FileManager.CreateFile(renderOutPath + "_SDK30/simple_peripheral_bds.c", rendered);
  log("Generated code file: "+renderOutPath+"_SDK30/simple_peripheral_bds.c");
  log("Modified sample-app file for Simple Peripheral project.")

  var rendered = PRZTemplate.render(formJson);
  FileManager.CreateFile(renderOutPath + "_SDK22/project_zero_bds.c", rendered);
  log("Generated code file: "+renderOutPath+"_SDK22/project_zero_bds.c");
  log("Modified sample-app file for Project Zero project.")
  var rendered = PRZTemplate30.render(formJson);
  FileManager.CreateFile(renderOutPath + "_SDK30/project_zero_bds.c", rendered);
  log("Generated code file: "+renderOutPath+"_SDK30/project_zero_bds.c");
  log("Modified sample-app file for Project Zero project.")

  FileManager.CreateFile(renderOutPath + "_log.txt", getLog());

  // function process_render_file(file, context)
  // {
  //   var parsed = FileManager.ReadFile(file);

  //   if (context)
  //     var parsed = Liquid.parse(parsed);
  //     var parsed = parsed.render(formJson);

  //   fileparts = file.split('.');
  //   log("Fileparts: " + fileparts);

  //   basename = fileparts.splice(fileparts.length-2, fileparts.length).join('.');
  //   log("basename: " + basename);

  //   pathname = fileparts.splice(1, fileparts.length).join('/');
  //   log("pathname: " + pathname);

  //   outpath = [context.profileName, pathname].join('/');
  //   log("Filename: " + outpath);

  //   outfile = outpath + '/' + basename;

  // }


  // log("Making JSON string");
  // output = JSON.stringify(formJson);

  // var filename = profiledata.ProfileName + "_JSON.txt";
  // log("Writing JSON string to file");
  // FileManager.CreateFile(filename, output);

}

